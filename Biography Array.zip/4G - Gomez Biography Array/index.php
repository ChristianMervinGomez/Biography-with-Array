<?php

$Student = array(
array("name" => " Christian Mervin C. Gomez ", "age" => "21 ", "Gender" => "Male ",)
);?>

<!DOCTYPE html>
<html>
<head>
	<title>Biograpy</title>
</head>
<body>
<table>
     <tr>
	<th> Name </th>
<th>Age</th>
<th>Gender</th>
      
    </tr>
<?php 
 foreach ($Student as $numericField => $data) {
	print "<tr>";
	foreach($data as $Studentfield => $StudentData){
  print "<td> $StudentData </td>";
        }
     
      ?>
       
   </table>

</body>
</html>
